AppleSettings = {
    LevelMax = "2001", -- Max Lvl U Want Reach
    TimerRjQueue = 35, -- Seconds For Queue Else Rejoin
    TimerForBroly = 180, -- Seconds For Broly Else Rejoin
    ExtraTimeToLoad = 0, 
    Senzu = false, -- spamm The Senzu
    PadQueue = 6, -- from 1 to 7
    Form = 2, -- 0 = Disabled / 1 = Android / 2 = Enabled
    FormBtn = "h", -- g or h
    ChargeWait = 3,
    Moves = { -- Leave Empty If U Dont Wanna use Every 10 Moves
        Move1 = "Flash Strike",
        Move2 = "Anger Rush",
        Move3 = "Deadly Dance",
        Move4 = "Meteor Crash",
        Move5 = "",
        Move6 = "",
        Move7 = "",
        Move8 = "",
        Move9 = "",
        Move10 = "",
    },
}
loadstring(game:HttpGet("https://raw.githubusercontent.com/malumsw/FS/main/abV1.0", true))()