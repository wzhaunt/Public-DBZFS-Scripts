   -------------------------------[Creado Por/Made By NabilDr]------------------------------------

   Settings = {
    ChargeForm = 0; --[select here the loading time to transform, recommended max 3.9]--
    FormType = "NONE"; --[Choose between "g" and "h" depending on the transformation you like or "NONE" if you dont need form]--
    ExtraTime = 0; --[[Time it will take for the script to run (recommended between 2s and 4s to avoid crashes)]]--
    AutoSenzu = true; --[false = do not spam jars or beans and true = if spam jars and beans]--
    UseMoves = true; --[disable it and the fast autopunch mode will be used]--
    Rejoin = false; --[recommended if you dont use blue beans/jars]--
    TimeToRestart = 600; --[recommended if you dont use blue beans/jars]--
    AutoPunchFast = false; --[Rights clicks spam]--
    AutoPunchSlow = false; --[Slow rights clicks]--
    MultiFarmAcctounts = false; --[True = Multible accounts using AUTOHTC at the same time]--
    IDPlayer = 1492348624; --[Your main account id here]--
    NerfHighStats = false; --[if you are inf activate this option to avoid killing goku]--
    autorejoinlvl = true; --[joins again after going up to the level where goku transforms into superior phase]--
    CooldownRejoinGoku = 60; --[seconds that will wait before rejoining when goku can use the next form]--
    on = true; --[True = The settings bellow will be enable]--
    CustomWeebhook = "";  --[put your own weebhook to get your lvl up info in discord]--
 }

 Moveset = {

    "TS Molotov",
    "Flash Skewer",
    "Vital Strike",
    "Time Skip",
    "Meteor Crash",
    "Wolf Fang Fist",
    "Mach Kick",
    "Neo Wolf Fang Fist",
    "Flip Kick",
 }




-------------------------------[Warn this is a free script]--------------------------------------
------------------------------\(👍≖‿‿≖)👍 👍(≖‿‿≖👍)/--------------------------------------



loadstring(game:HttpGet'https://raw.githubusercontent.com/NeiKiNDR/NDR2023/main/AHparte1.lua')()
