-------------------------------[Creado Por/Made By NabilDr]------------------------------------

Transform = {
    FormType = "None"; --[What key to press when using form, g or h, None to dont transform]--
    ChargeForm = 0; --[How long charge before using a form]--
}

Settings = {
    FpsBoost = false; --[True = Better fps and less lag]--
    PetTime = 5; --[True = Spam pet]--
    StatsAFK = false; --[The settings below will be enable]--
    AutoStats = "Phys-Damage"; --[Wich stat you want to auto upgrade. Example: Phys-Resist, Ki-Max, Health-Max, Ki-Resist, Ki-Damage,Phys-Damage, Speed]--
    AutoPunchLowKi = false; --[When you run out of ki it will start giving right clicks]--
    AutoPunch = false; --[Rights clicks spam]--
}

Moveset = {
    "Blaster Meteor",  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Chain Destructo Disk",
}

--[[

    -------------------------------[Moveset for each damage]-------------------------------

For melee moves i suggest use:

    "Flash Strike";  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Sweep Kick";

Or this one:

    "Deadly Dance";  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Anger Rush";
    "Meteor Crash";

And for ki moves i suggest use:

    "Blaster Meteor",  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Chain Destructo Disk",

And for big melee moveset i suggest this one:

    "Neo Wolf Fang Fist";  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Wolf Fang Fist";
    "Anger Rush";
    "Flash Skewer";
    "Meteor Crash";
    "Deadly Dance";
    "TS Molotov";
    "Sweep Kick";
    "God Slicer";
]]--

----------------------------/////{Advanced Settings-Ajustes Avanzados}\\\\\---------------------------------

AdvancedSettings = {
    on = true; --[True = The settings bellow will be enable]--
    Cooldown = 0; --[Electron = recommended 1 / others = 0]--
    ExtraTime = 0; --[How long untill the scripts load. Recommended Synapse X = 0, Krnl = 1-2. Increase if the script is not working when in autoexe]--
    MultiFarmAcctounts = false; --[True = Multible accounts using autobroly at the same time]--
    IDPlayer = 43543535; --[Your main account id here]--
    RejoinInTime = 160;  --[Select here The Max Time To Wait In Broly Map Before to Teleport to Queue]--
    Advertise = true; --[Promote your carries and the owner's server <3]--
    FOV = 120; --[Field of view]--
    LvlMaxFilter = "2000";  --[Select here The Max Lvl you want get]--
    DuoAb = false;  --[Autobroly duo]--
    MainUserName = ""; 
    SeconUserName = "";
    HeavenMode = false; --[Warning its a beta mode and you need a lot of damage/ki - around 100k base!]--
    SlotNotHeaven = "Slot1";
    SlotHeaven = "Slot2";
    PadSelection = "Random"; --[Put Random to select it aleatory or put pad1 or pad2 or pad3 or pad4 or pad5 or pad6 or pad7]--
    
}

TypeBroly = {
    GoEarth = false; --[True = Teleport to earth broly pad instead of queue]--
    CameraLock = true; --[True = Locks on to broly like aimbot (only visual)]--
    GoSolo = false; --[True = kick you when more then 2 total people are in broly world]--

}

Customizable = {
    SkyMode = false; --[True = you will be able to customize the sky]--
    IDSkyBroly = "http://www.roblox.com/asset/?id=7427648722"; --[Put your sky id/link here]--
    CustomWeebhook = "";  --[put your own weebhook to get your lvl up info in discord]--
}

-------------------------------[Warn this is a free script]--------------------------------------
------------------------------\(👍≖‿‿≖)👍 👍(≖‿‿≖👍)/--------------------------------------



loadstring(game:HttpGet'https://raw.githubusercontent.com/NeiKiNDR/NDR2023/main/ABparte1.lua')()
