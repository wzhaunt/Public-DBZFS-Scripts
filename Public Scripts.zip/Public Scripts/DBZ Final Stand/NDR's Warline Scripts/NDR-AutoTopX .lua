-------------------------------[Creado Por/Made By NabilDr]------------------------------------


--[ For Normal Top : Zenni or zenni / Exp or exp / Prestige or prestige / Level Cap or lvl cap ]--
--[ For Hard Top : Death or death / God or god / Nothing or nothing ]--

Settings  = {
    TypeTop = "normal"; --[Type normal or hard]--
    GoEarth = false; --[True = go to the chairs top in Earth]--
    AutoWish = false; --[True = Choose the wish automatically]--
    Wish = "Zenni"; --[Normal Top= Zenni-Exp-Prestige-Level Cap /// Hard Top= Death-God-Nothing]--
    ChargeForm = 3; --[Delay time transforming]--
    FormType = "h"; --[G form or H form]--
    KiMode = false; --[New mode for ki damage/Turn False for normal top mode]--
    PauseKey = "p"; --[Pause/Reanude the script]--
    StatsAFK = false; --[Automatically place skill points]--
    AutoStats = "Phys-Damage"; --[Ki-Damage/Phys-Damage/Ki-Resist/Phys-Resist/Health-Max/Ki-Max/Speed]--
    PetTime = 60; --[Use your pet the second you put/put "No" to dont use it]--
    AutoPunchLowKi = true; --[When you run out of ki it will start giving right clicks]--
    MultiFarmAcctounts = false; --[True = Multible accounts using Auto Top at the same time]--
    IDPlayer = 324552424; --[Your main account id here]--
    AutoBuy = false; --[Auto Buyer of Beans / Jars]--
    MinMoney = 50000; --[Minium money]--
    MaxMoney = 2000000; --[Maximum money]--
    TypeBuy = "Beans"; --["Beans", "Jars"]--
    HowMuchBuy = "80"; --["80", "8"]--
    ColorBeans = "Red"; --["Blue", "Red", "Green", "Yellow"]--
    Advertise = true; --[Promote your carries and the owner's server <3]--
    AutoSenzu = true; --[Spam Beans/Jars]--
    ExtraTime = 0; --[Time to wait before starting the script]--
    RejoinTime = 300; --[Time to stay in the top]--
    CustomWeebhook = "";  --[put your own weebhook to get your lvl up info in discord]--
}

Moveset = {

    "Flash Strike";  --[These moves are the recommended for the fastes time (if you have infistats melee damage) but you can choose as many moves as you like]--
    "Sweep Kick";

}

--[[

-------------------------------[Moveset for each damage]-------------------------------

For melee moves i suggest use:

    "Flash Strike";  --[These moves are the recommended for the fastes time (if you have infistats melee damage) but you can choose as many moves as you like]--
    "Sweep Kick";

Or this one:

    "Deadly Dance";  --[These moves are the recommended for the fastes time (if you have infistats melee damage) but you can choose as many moves as you like]--
    "Anger Rush";
    "Meteor Crash";

And for ki moves i suggest use:

    "Chain Destructo Disk",  --[These moves are the recommended for the fastes time (if you have infistats ki damage) but you can choose as many moves as you like]--
    "Finish Breaker",

And for big melee moveset i suggest this one:

    "Neo Wolf Fang Fist";  --[These moves are the recommended for the fastes time (if you have infistats melee damage) but you can choose as many moves as you like]--
    "Wolf Fang Fist";
    "Anger Rush";
    "Flash Skewer";
    "Meteor Crash";
    "Deadly Dance";
    "TS Molotov";
    "Sweep Kick";
    "God Slicer";
]]--



-------------------------------[Warn this is a free script]--------------------------------------
------------------------------\(👍≖‿‿≖)👍 👍(≖‿‿≖👍)/--------------------------------------



loadstring(game:HttpGet'https://raw.githubusercontent.com/NeiKiNDR/NDR2023/main/ATparte1.lua')()
