These Scripts are NOT mine there all made by their respective creators.

DBZ Final Stand:

TheUnknownScripter's Server:
https://discord.gg/2BfG9esrEZ

AppleSW Server:
https://discord.gg/xvEr2AsvK5

NDR/Warline Server:
https://discord.gg/gXVhBYdFMN

Booga41 Server:
Fuck Booga :)

Everyone else I don't know you sadly.